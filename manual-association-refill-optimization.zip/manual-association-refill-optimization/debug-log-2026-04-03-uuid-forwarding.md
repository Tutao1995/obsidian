# debug-log-2026-04-03-uuid-forwarding

## Bug 修复进度
- [x] 阶段 1：理解问题（收集症状/日志/代码位置）
- [x] 阶段 2：定位相关代码（搜索 → 阅读 → 确定边界）
- [x] 阶段 3：分析原因（列出假设，分配置信度）
- [x] 阶段 4：质疑根本原因（高置信度时必须执行）
- [x] 阶段 5：修复或进一步调查
- [x] 阶段 6：修复审查（子 agent 六维度 review）
- [x] 阶段 7：产出排查记录（输出结构化 md）

## 症状
- 测试环境调用 `/seeyon/rest/cap/comi/agent/fill-back/stream` 时后端抛出：
  - `Unrecognized field "UUID" (class com.seeyon.cap4.agent.common.aiaction.dto.InvokeAgentDto)`
- 说明请求体中包含了后端 DTO 未定义的 `UUID` 字段。

## 排查步骤 todoList
1. 检查宿主 `cap4-ai-modal/index.js` 中抽取前初始化请求的参数清洗逻辑。
2. 检查 `formExtractionStream/App.vue` 中统一请求清洗逻辑与重试链路。
3. 对照异常日志中的接口 `/rest/cap/comi/agent/fill-back/stream` 与前端本次改动，确认新增请求是否把 `UUID` 透传。
4. 修复参数清洗逻辑，仅删除前端内部流式事件标识 `UUID`，不改业务参数。
5. 重新执行 `pc_form` 与 `app_center` 构建。
6. 进行独立子 agent 审查。
7. 重新上传测试环境。

## 假设与验证
| 步骤 | 假设 | 验证结果 |
|---|---|---|
| 1 | 宿主新增的抽取前初始化请求没有清掉 `UUID` | 命中。`buildExtractRequestData()` 删除了 `source/messageInfo/customParam/_prefetchedStreamParams`，但未删除 `UUID`。 |
| 2 | 页面内重试链路也可能继续透传 `UUID` | 命中。`getCleanParams()` 原先也未删除 `UUID`。 |
| 3 | 后端报错接口与本次新增预校验请求是同一条链路 | 命中。日志中的 `/rest/cap/comi/agent/fill-back/stream` 正是宿主预请求与 AI 按钮链路使用的接口。 |
| 4 | 这是逻辑问题，不是需求/设计问题 | 命中。`UUID` 仅是前端流式事件关联字段，不属于后端 DTO 业务字段。 |

## 根因定位链
1. 本次前端为了在打开主弹窗前做场景预判，新增了一次“抽取前初始化请求”。
2. 该请求复用了原始 `options`，其中包含前端流式组件使用的 `UUID`。
3. 宿主的 `buildExtractRequestData()` 没有删除 `UUID`。
4. 后端 `InvokeAgentDto` 不接受 `UUID` 字段，Jackson 反序列化直接抛 `UnrecognizedPropertyException`。
5. 页面 `getCleanParams()` 同样未删除 `UUID`，意味着重试链路也存在同类风险。

## 质疑根本原因
- 需求问题？否。需求没有要求向后端透传 `UUID`。
- 方案问题？否。前置预校验本身不是问题，问题出在参数清洗不完整。
- 设计问题？否。设计要求的是场景预判，不要求把前端内部字段发给后端。
- 逻辑问题？是。前端在构造请求体时遗漏删除 `UUID`。

## 最终修复方案
### 修改点
1. `pc_form/src/components/widgets/cap4-ai-modal/index.js`
   - 在 `buildExtractRequestData()` 中新增 `delete data.UUID;`
   - 理由：`UUID` 仅用于前端流式事件关联，不属于后端 `InvokeAgentDto` 字段。
2. `app_center/src/views/formExtractionStream/App.vue`
   - 在 `getCleanParams()` 中新增 `delete cleanParams.UUID;`
   - 理由：统一覆盖页面初始化与重试链路，避免后续再次把前端内部字段透传给后端。

### 为什么这样改
- 这是最小修复。
- 不改变任何业务判定规则。
- 只移除前端内部使用、后端不识别的字段。
- 同时覆盖首次进入与重试链路，避免同类问题二次出现。

## 构建验证
- `npm14 --prefix "D:/code/web/cap-front/pc_form" run build`：通过
- `npm14 --prefix "D:/code/web/cap-front/app_center" run build -- aiExtractionConfigDialog aiRelationBackfillDialog formExtractionStream`：通过

## 修复审查摘要
子 agent 审查结论：
- 对症性：命中根因
- 冗余性：提示当前提交夹带较多非本 bug 必需改动，但 UUID 修复本身正确
- 影响范围：UUID 修复本身范围可控

## 补充同类问题
在修复 `UUID` 后，测试环境继续暴露了同类异常：
- `Unrecognized field "_url"`

进一步排查确认：`_url` 也是前端内部调度字段，不属于后端 DTO，应与 `UUID` 一并在清洗阶段删除。

补充修复：
1. `pc_form/src/components/widgets/cap4-ai-modal/index.js`
   - `buildExtractRequestData()` 中新增 `delete data._url;`
2. `app_center/src/views/formExtractionStream/App.vue`
   - `getCleanParams()` 中新增 `delete cleanParams._url;`

## PRD 偏差复盘与收敛
后续测试发现前端为了兼容旧流参数返回，曾加入“合法流参数直接放行”逻辑，导致在后端未返回场景码时绕过 PRD 要求的可编辑字段/抽取范围门禁。

收敛修复：
1. 删除 `hasValidStreamParams(sceneData)` 直接放行路径。
2. `interceptExtractScene()` 只接受明确场景码：
   - `NO_EDITABLE_FIELD`：提示并终止
   - `NO_FIELD_IN_SCOPE`：提示弹窗，右上角提供查看抽取配置入口，并终止
   - `HAS_FIELD_IN_SCOPE`：继续抽取
   - 其他：提示初始化数据异常并终止
3. 将主提取弹窗的“查看抽取配置”从底部按钮改到标题右上角。
4. 场景二提示弹窗也在标题右上角提供“查看抽取配置”入口，避免用 confirm 按钮替代 PRD 交互。

复审/验收：
- 独立 review：PASS
- 独立 verify：PASS

## 后续动作
- 重新合并 dist 产物
- 重新上传测试环境
- 由测试环境复现原路径，确认不再出现 `Unrecognized field "UUID"` / `Unrecognized field "_url"`
- 同时确认无编辑权限字段不会再因旧流参数放行而被写入，右上角“查看抽取配置”入口可见

## 初始化异常排查日志
为定位仍然出现的“当前抽取任务初始化数据异常，请稍后重试”，已在宿主增加可搜索特征日志：
- `[AI_EXTRACT_SCENE_DEBUG][requestExtractStreamParams:success]`
- `[AI_EXTRACT_SCENE_DEBUG][interceptExtractScene]`
- `[AI_EXTRACT_SCENE_DEBUG][invalidScene]`

日志内容会输出：
- 返回体 keys
- `extractSceneCode`
- `showExtractConfigEntry`
- 是否存在 `extractConfigSections`
- 是否存在 `agentCode/input/extractAgentCode/extractInput`

用途：
- 判断后端到底返回的是“新场景结构”还是“旧流参数结构”
- 判断前端为什么落入 `invalidScene` 分支
