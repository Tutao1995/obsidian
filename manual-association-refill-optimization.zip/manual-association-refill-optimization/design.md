> 来源: spec.md
> 生成时间: 2026-04-02
> 阶段: design

### Why

**背景与现状**

当前智能提取/回填前端宿主集中在 `pc_form/src/components/widgets/cap4-ai-modal/index.js`，负责打开提取弹窗、处理一键回填、承接手动关联选择和失败弹窗。提取内容页集中在 `app_center/src/views/formExtractionStream/App.vue`，已经支持提取态与手动关联态双视图切换；失败反馈页集中在 `app_center/src/views/aiRelationBackfillDialog/App.vue`。四类入口分别从 `custom_components/packages/custom-ai-btn/index.js`、`pc_form/src/mixins/utils/form-controlWork.js`、`pc_form/src/mixins/comi/comi.js` 进入同一宿主。

现状已具备“手动关联候选选择”和“回填失败汇总”两类弹窗能力，但抽取前的不可执行原因仍依赖后端 message 或通用错误文案，前端没有统一的场景模型，也没有“查看抽取配置”弹窗承载页，因此相同业务场景在不同入口上的提示不一致。

**设计目标 / 非目标**

| 类型 | 说明 |
|------|------|
| ✅ 目标 | 在现有 `cap4-ai-modal + formExtractionStream` 链路内补齐抽取前场景模型，统一四类入口提示与交互 |
| ✅ 目标 | 复用现有弹窗/iframe 通信模式，新增“查看抽取配置”承载页并支持主表/明细表分组展示 |
| ✅ 目标 | 保持一键回填失败反馈继续复用现有失败弹窗，只扩展数据结构和触发时机 |
| ❌ 非目标 | 不改造 AI 流式回答、抽取算法、字段筛选算法、手动关联匹配算法 |
| ❌ 非目标 | 不新增数据库表、缓存、全局状态管理，也不改造四类入口之外的调用方 |

### What

#### 技术方案

**架构决策**

| 模块 | 职责 | 依赖 |
|------|------|------|
| `pc_form/src/components/widgets/cap4-ai-modal/index.js` | 统一解释后端返回的场景结果；决定提示、是否继续抽取、是否打开配置弹窗或失败弹窗 | `formExtractionStream`、`aiRelationBackfillDialog`、新增配置弹窗页、各入口传入的 options/fillBackParam |
| `app_center/src/views/formExtractionStream/App.vue` | 继续承载提取态/手动关联态与已有内容展示；不承担抽取前场景判断，只保留宿主需要的页面内视图切换能力 | `ManualRelationSelectorTable.vue`、宿主 `transParams` 回调 |
| `app_center/src/views/aiRelationBackfillDialog/App.vue` | 继续承载回填失败汇总展示，消费统一失败数据结构 | 宿主 `transParams.fails` |
| `app_center/src/views/aiExtractionConfigDialog/App.vue`（新增） | 展示抽取配置字段范围，按主表/明细表分组展示字段名称、字段类型、是否可编辑 | 宿主 `transParams.configSections` |
| 四类入口调用方 | 继续负责预保存、组装 options，不单独分支处理场景提示 | `cap4-ai-modal` |
| 后端抽取/回填返回体 | 在现有接口返回中补充抽取前场景码、配置弹窗数据、统一 message 文案 | 现有 `extract-stream-param` / `fill-back` / `intelligentExtractFillBack` 返回链路 |

模块关系：四类入口继续只调用 `window.SY.globals.$AIModal`。`cap4-ai-modal` 作为唯一宿主解释后端返回的新场景字段：命中不可执行场景时直接拦截并提示；命中可查看配置场景时由宿主按钮打开新增配置弹窗；命中回填失败时继续打开现有失败弹窗。`formExtractionStream` 不新增业务判定，也不承载抽取配置入口，只保留提取态与手动关联态的页面能力，保证四类入口的行为一致。

**数据模型变更**

| 操作 | 表/实体 | 字段 | 类型 | 约束 | 说明 |
|------|---------|------|------|------|------|
| 新增 | 提取前校验返回 DTO | `extractSceneCode` | `String` | 非持久化 | 标识 `NO_EDITABLE_FIELD`、`NO_FIELD_IN_SCOPE`、`HAS_FIELD_IN_SCOPE` |
| 新增 | 提取前校验返回 DTO | `extractSceneMessage` | `String` | 非持久化 | 场景对应提示文案，前端优先消费该字段 |
| 新增 | 提取前校验返回 DTO | `showExtractConfigEntry` | `Boolean` | 非持久化 | 控制是否显示“查看抽取配置”入口 |
| 新增 | 提取前校验返回 DTO | `extractConfigSections` | `List<ExtractConfigSectionVO>` | 非持久化 | 配置弹窗展示数据，按主表/明细表分组 |
| 新增 | `ExtractConfigSectionVO` | `sectionType/sectionName/fields` | `String/List` | 非持久化 | 描述一组主表或明细表字段 |
| 新增 | `ExtractConfigFieldVO` | `fieldName/fieldLabel/fieldType/editable/tableName/tableDisplay` | `String/Boolean` | 非持久化 | 配置弹窗单字段展示数据 |
| 扩展 | 回填结果 DTO | `relationBackfillFails[*].displayValue/relationName/reasonCode/reason/tableName/tableDisplay/rowIndex` | 现有字段补齐 | 非持久化 | 满足失败弹窗主表/明细表分组与错误展示 |

实体关系：`ExtractConfigSectionVO 1:N ExtractConfigFieldVO`。无数据库变更。

**接口定义**

| 接口 | 方法 | 路径/签名 | 入参 | 出参 | 说明 |
|------|------|----------|------|------|------|
| 抽取参数查询接口 | POST | `/api/cap/agent/fill-back/extract-stream-param` | 现有表单上下文参数 + `targetFieldIds/messageInfo/mergeData` | 现有流式参数 DTO + `extractSceneCode` + `extractSceneMessage` + `showExtractConfigEntry` + `extractConfigSections` | AI 节点对话框回填入口在真正抽取前获取场景结果 |
| AI 按钮流式抽取接口 | POST | `/rest/cap/comi/agent/fill-back/stream` | 现有 AI 按钮参数 + `mergeData` | 现有流式参数 DTO + 同上场景字段 | AI 按钮入口使用统一场景结构 |
| 文本/附件提取流式接口 | POST | `/rest/cap/comi/agent/intelligent-extract/stream` | 现有字段提取参数 + `mergeData` | 现有流式参数 DTO + 同上场景字段 | 文本/文本域/富文本、附件入口使用统一场景结构 |
| 一键回填接口 | POST | `CAP4AgentApiAjaxProxyService.intelligentExtractFillBack(Map<String, Object> request)` | 现有 `streamContent`、表单上下文、`selectedManualRelationMappings` | 现有回填结果 DTO + `relationBackfillFails` | 继续返回手动关联候选与失败清单，不新增独立接口 |
| 宿主打开配置弹窗方法 | JS 方法 | `showExtractConfigDialog(configSections)` | `Array<ExtractConfigSectionVO>` | `void` | `cap4-ai-modal` 内新增方法，负责打开配置弹窗 |
| 配置弹窗取值方法 | JS 方法 | `window.OK(): null` | 无 | `null` | 与现有 iframe 弹窗保持一致，只承载展示 |

> 前端不新增独立 HTTP API 文件；继续复用现有后端接口，只扩展返回结构。

**错误处理策略**

| 错误类型 | 处理方式 | HTTP状态码/异常类 |
|---------|---------|----------------|
| `NO_EDITABLE_FIELD` | 宿主直接 `alert` 场景文案并终止流程 | 业务成功返回，前端按场景码拦截 |
| `NO_FIELD_IN_SCOPE` | 宿主展示场景文案并提供“查看抽取配置”入口；不启动流式抽取 | 业务成功返回，前端按场景码拦截 |
| `HAS_FIELD_IN_SCOPE` 但缺少 `extractConfigSections` | 宿主继续抽取，但“查看抽取配置”按钮置灰或不展示；同时记录统一错误提示 | 业务成功返回，前端降级 |
| 配置弹窗数据为空 | 配置弹窗展示空状态，不抛 JS 异常 | 前端组件内兜底 |
| 一键回填存在 `relationBackfillFails` | 宿主关闭进度条后打开失败弹窗，不再只依赖成功 toast | 业务成功返回，前端按返回体处理 |
| 抽取/回填接口返回通用异常 | 保持现有 `alert(message)` 路径，不混入场景文案 | 现有 HTTP/业务异常 |

#### 关键决策与理由

| 决策 | 可选方案 | 选择 | 理由 |
|------|---------|------|------|
| 抽取前场景判断放在哪里 | A: 四类前端入口各自判断 / B: 宿主 `cap4-ai-modal` 统一判断 / C: 后端返回场景，宿主统一解释 | C | 四类入口已经统一汇聚到宿主，后端掌握最终抽取范围和权限结果；把场景计算放后端、解释放宿主，既保证口径唯一，也避免四个入口重复实现 |
| “查看抽取配置”承载方式 | A: 在 `formExtractionStream` 内嵌区域展示 / B: 新增独立 iframe 弹窗页 / C: 浏览器原生 alert | B | 现有宿主已大量使用 iframe dialog + `transParams` 通信，新增独立页可复用现有弹窗栈、避免侵入流式页面布局，也更适合主表/明细表分组表格展示 |
| 回填失败弹窗是否重做 | A: 重写失败弹窗 / B: 复用 `aiRelationBackfillDialog` 扩展数据结构 | B | 现有失败弹窗已支持主表/明细表分组和错误原因渲染，扩展成本最低，满足 D2 最简方案 |
| 四类入口的接入策略 | A: 每个入口单独拼提示与按钮 / B: 入口仅透传原参数，宿主统一处理 | B | 入口文件分散且职责是预保存与参数组装，继续保持最小职责更稳定；统一处理可保证文案和交互一致 |
| 配置数据是否前端二次推导 | A: 前端从 `formData` 推导字段范围 / B: 后端直接返回配置分组数据 | B | 抽取范围依赖后端配置和权限过滤，前端只能看到当前表单元数据，无法可靠推导“配置字段但不在范围内”的最终结果 |
| 风险控制方式 | A: 新增接口 / B: 扩展现有接口返回结构 | B | 本次是增量展示优化，没有独立业务域；扩展原返回结构可减少联调点和发布面 |

#### 风险与权衡

| 风险 | 概率 | 影响 | 缓解措施 |
|------|------|------|---------|
| 扩展现有抽取接口返回结构后，旧调用方未兼容新字段或错误地依赖 `message` | 中 | 中 | 新字段全部按可选字段追加，保留现有 `message/code/data` 结构；宿主优先判断新字段，旧调用方不受影响 |
| 四类入口虽然共用宿主，但某些入口返回结构不同，导致场景化提示遗漏 | 中 | 高 | 以宿主为唯一解释层，联调时按四类入口逐项验收场景一到场景四；设计中不允许入口私有分支绕过宿主 |
| 新增配置弹窗页后，国际化 key 未及时导出，导致页面显示 key 字符串 | 中 | 中 | 与前端改动同步补齐本模块 i18n 资源；编码阶段先搜索现有 key，再新增缺失 key |

**发布策略**（如需）：
- **发布方式**：一次性
- **回滚条件**：任一入口出现无法进入抽取流程、弹窗无法关闭、旧成功回填流程被阻断
- **兼容性**：后端新增字段按可选扩展返回；前端上线前不依赖移除旧字段

#### 变更文件清单

| 文件路径 | 操作 | 变更说明 |
|---------|------|---------|
| `pc_form/src/components/widgets/cap4-ai-modal/index.js` | 修改 | 新增抽取前场景解释、查看配置宿主按钮、统一场景提示分发 |
| `app_center/src/views/formExtractionStream/App.vue` | 视情况修改 | 若需配合宿主展示状态或保留页面切换能力，保持提取态/手动关联态切换 |
| `app_center/src/views/formExtractionStream/components/ManualRelationSelectorTable.vue` | 修改 | 如需补充分组文案或统一字段展示，保持与配置弹窗风格一致 |
| `app_center/src/views/aiRelationBackfillDialog/App.vue` | 修改 | 按统一失败数据结构补充展示字段或空态 |
| `app_center/src/views/aiExtractionConfigDialog/App.vue` | 新增 | 新增抽取配置查看弹窗页 |
| `pc_form/src/mixins/utils/form-controlWork.js` | 视情况修改 | 若入口需透传额外上下文，保持最小改动接入宿主 |
| `pc_form/src/mixins/comi/comi.js` | 视情况修改 | 若 AI 节点入口需透传额外上下文，保持最小改动接入宿主 |
| `custom_components/packages/custom-ai-btn/index.js` | 视情况修改 | 若 AI 按钮入口需透传额外上下文，保持最小改动接入宿主 |
| 后端对应抽取/回填接口实现文件 | 修改 | 扩展场景码、配置分组数据、失败清单返回结构 |

### How

#### 任务拆分

| 任务名称 | 详细描述 | 关联设计章节 | 计划工作量(人天) |
|----------|---------|------------|--------------|
| 【场景模型】(后端) 扩展抽取前返回结构 | 1. 在三条抽取前接口链路补充 `extractSceneCode`、`extractSceneMessage`、`showExtractConfigEntry`、`extractConfigSections`<br>2. 统一三类场景码和文案返回规则<br>3. 保持旧返回结构兼容 | 数据模型变更 / 接口定义 / 错误处理策略 | 1 |
| 【配置数据】(后端) 组装抽取配置分组结果 | 1. 输出主表/明细表分组结构<br>2. 补齐字段名称、字段类型、当前是否可编辑等展示字段<br>3. 在场景二和场景三下返回可直接展示的数据 | 数据模型变更 / 接口定义 | 1 |
| 【宿主分发】(前端) 统一解释场景结果 | 1. 在 `cap4-ai-modal` 增加场景结果解释层<br>2. 命中场景一/二时直接拦截并提示，不进入流式提取<br>3. 命中场景三时在宿主按钮区挂载“查看抽取配置”动作并继续抽取 | 架构决策 / 错误处理策略 | 1 |
| 【配置弹窗】(前端) 实现查看抽取配置页面 | 1. 新增配置弹窗承载页<br>2. 按主表/明细表分组展示字段名称、字段类型、当前是否可编辑<br>3. 处理空状态与关闭行为 | 架构决策 / 数据模型变更 | 1 |
| 【失败反馈】(前端) 对齐回填失败展示 | 1. 继续复用 `aiRelationBackfillDialog`<br>2. 校准主表/明细表分组、字段值、关联数据源、错误原因展示<br>3. 确保四类入口均走统一失败弹窗路径 | 错误处理策略 / 变更文件清单 | 1 |
| 【入口联调】(全栈) 验证四类入口一致性 | 1. 覆盖 AI 按钮、文本/文本域/富文本、附件、AI 节点四类入口<br>2. 验证场景一至场景四完整链路<br>3. 验证兼容旧成功流程与关闭行为 | 风险与权衡 / 发布策略 | 1 |
| **合计** | | | **6** |

**任务排序原则**：先后端场景模型与配置数据 → 再前端宿主分发 → 再配置弹窗与失败反馈 → 最后四入口联调。

**任务依赖**（如有）：

```
- 【场景模型】(后端) 扩展抽取前返回结构
- 【配置数据】(后端) 组装抽取配置分组结果 ← depends: 【场景模型】(后端) 扩展抽取前返回结构
- 【宿主分发】(前端) 统一解释场景结果 ← depends: 【场景模型】(后端) 扩展抽取前返回结构
- 【配置弹窗】(前端) 实现查看抽取配置页面 ← depends: 【配置数据】(后端) 组装抽取配置分组结果
- 【失败反馈】(前端) 对齐回填失败展示 ← depends: 【宿主分发】(前端) 统一解释场景结果
- 【入口联调】(全栈) 验证四类入口一致性 ← depends: 【配置弹窗】(前端) 实现查看抽取配置页面
- 【入口联调】(全栈) 验证四类入口一致性 ← depends: 【失败反馈】(前端) 对齐回填失败展示
```

### Verify

```
设计自检：
- [x] 所有 spec 功能需求都有对应的技术方案
- [x] 所有技术决策都有理由
- [x] 接口定义完整（入参、出参、异常）
- [x] 数据模型变更明确（新增/修改/删除）
- [x] 任务拆分覆盖全部设计内容
- [x] 任务总量与需求规模匹配
- [x] 无实现代码（只有签名和结构）
- [x] 已按 .best-practices/ 约束检查 Risks/Rollout
```

### Impact

- `pc_form`：宿主弹窗逻辑会新增场景解释层，但不改变既有入口调用方式
- `app_center`：新增配置弹窗页，并调整提取页/失败页的数据消费方式
- 数据库变更：否
- 外部依赖变更：否，仅扩展现有后端接口返回结构
